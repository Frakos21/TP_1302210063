<?php

namespace App\Http\Controllers;

use App\Models\Pegawai;
use Illuminate\Http\Request;

class PegawaiController extends Controller
{
    public function index()
    {
        $pegawais = Pegawai::all();
        return view('pegawai', compact('pegawais'));
    }

    public function tambahData(Request $request){
        $validatedData = $request->validate([
            'name' => 'required',
            'posisi' => 'required',
            'gaji' => 'required|numeric',
        ]);

        $pegawai = new Pegawai();
        $pegawai->name = $validatedData['name'];
        $pegawai->posisi = $validatedData['posisi'];
        $pegawai->gaji = $validatedData['gaji'];
        $pegawai->save();
        return redirect('/pegawai');
    }
}
