<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Daftar Pegawai</title>
    <h1>Daftar Pegawai</h1>
</head>
<body>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Name</th>
                <th scope="col">Posisi</th>
                <th scope="col">Gaji</th>
            </tr>
        </thead>
    <tbody>
        <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($pegawai->name); ?></td>
            <td><?php echo e($pegawai->posisi); ?></td>
            <td><?php echo e($pegawai->gaji); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
    <form action ="/tambah" method="POST">
        <?php echo csrf_field(); ?>
        <input class="form-control" id="Input" type="text" placeholder="Name" name="name">
        <input class="form-control" id="Input" type="text" placeholder="Posisi" name="posisi">
        <input class="form-control" id="Input" type="text" placeholder="Gaji"name="gaji"><br>   
        <button type="submit" class="btn btn-primary">Data Insert</button> 
    </form>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Users\asus\Pictures\listPegawai\resources\views/pegawai.blade.php ENDPATH**/ ?>